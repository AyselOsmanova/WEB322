/*********************************************************************************
*  WEB322 – Assignment 1
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy.  
*  No part of this assignment has been copied manually or electronically from any other source
*  (including web sites) or distributed to other students.
* 
*  Name: Aysel Osmanova Student ID: 123615163 Date: 1.14.2019
*
*  Online (Heroku) URL:https://a--1.herokuapp.com/


var HTTP_PORT=process.env.PORT || 8080;
var express = require ("express");
var app = express();

app.get("/", (req,res)=> {

    res.send("Aysel Osmanova-123615163");

});

app.listen(HTTP_PORT);